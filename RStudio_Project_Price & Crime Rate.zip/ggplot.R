library(tidyverse)

#File1 %>%

#File1[c(1,2, 3, 4, 5, 6, 7, 8, 9)]

#File1[ , nrow(1, 2, 3, 4)]

#File1%>% select(length(3:3))

#select((File1[1:4]))

ggplot(File1, aes(x=Country, y =Value, color= Inequality)) + geom_point() + scale_y_log10()
