install.packages(tidyverse)
library(tidyverse)



data()



view(File_for_Midterm_1_)


File_for_Midterm_1_ %>%
  group_by(Location) %>%
  summarise('Average price'= mean(Price),
            'Lowest price' = min(Price),
            'Highest price' = max(Price)) %>%
  view






