library(tidyverse)

BLI_10062023225605472 %>%
  group_by(Location) %>%
  summarise('Feeling safe walking alone at night'= count(),
            'Lowest price' = min(Price),
            'Highest price' = max(Price),
            'Average Crime Rate'= mean(`Crime Rating`),
            'Lowest Crime Rate' = min(`Crime Rating`),
            'Highest Crime Rate' = max(`Crime Rating`)) %>%
  view("midsem_data")

Men_Index <- c(Value$ 1:9) # create a numeric vector
Women_Index  <- c(120321,188752) # create a numeric vector
Highest_Price <- c(402315, 750250) # create a numeric vector
Average_Crime_Rate <- c(3.74,3.85) # create a numeric vector
Lowest_Crime_Rate <- c(1,1) # create a numeric vector
Highest_Crime_Rate <- c(8,9) # create a numeric vector
midsem <- cbind(Average_Price,Lowest_Price,Highest_Price,Average_Crime_Rate, Lowest_Crime_Rate,Highest_Crime_Rate) # create a matrix
d <- as.data.frame(m) # create a data frame
Location <- c("FL", "NY") # create a text vector
midsem <- cbind(Location,m)# add the text vector to the data frame

write.csv(midsem , file = "midsem.csv")
