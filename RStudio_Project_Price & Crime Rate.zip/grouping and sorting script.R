library(tidyverse)

File_for_Midterm_1_%>%
  group_by(Location)%>%
  summarise('Average price'= mean(File_for_Midterm_1_$Price),
            'Lowest price' = min(File_for_Midterm_1_$Price),
            'Highest price' = max(File_for_Midterm_1_$Price),
            'Average Crime Rate'= mean(File_for_Midterm_1_$`Crime Rating`),
            'Lowest Crime Rate' = min(File_for_Midterm_1_$`Crime Rating`),
            'Highest Crime Rating' = max(File_for_Midterm_1_$`Crime Rating`))%>%
  view("Midsem_data")
